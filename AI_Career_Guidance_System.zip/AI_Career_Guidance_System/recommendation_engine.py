CAREERS = {
    "Software Developer": {"skills":["programming","python","java","problem solving","sql"],"interests":["coding","software","technology"],"branches":["computer science","cse","it","information technology"],"description":"Builds and maintains software applications.","roadmap":["Learn one programming language","Practice data structures and algorithms","Build small applications","Learn databases and Git","Create a portfolio project"]},
    "AI Engineer": {"skills":["python","machine learning","math","data analysis"],"interests":["artificial intelligence","automation","research"],"branches":["computer science","cse","it","ai","artificial intelligence"],"description":"Develops intelligent systems that learn and make predictions.","roadmap":["Strengthen Python and mathematics","Learn data handling","Study machine learning basics","Build an AI project","Learn model deployment"]},
    "Machine Learning Engineer": {"skills":["python","statistics","machine learning","data analysis"],"interests":["machine learning","research","automation"],"branches":["computer science","cse","it","ai"],"description":"Creates and deploys machine-learning models.","roadmap":["Learn Python and statistics","Study supervised learning","Practice with datasets","Build prediction projects","Learn model evaluation and deployment"]},
    "Data Scientist": {"skills":["python","statistics","sql","data analysis"],"interests":["data","analytics","research"],"branches":["computer science","cse","it","mathematics"],"description":"Uses data and statistical methods to solve problems.","roadmap":["Learn Python and SQL","Study statistics","Practice data visualization","Complete data analysis projects","Learn machine learning foundations"]},
    "Data Analyst": {"skills":["excel","sql","data analysis","visualization"],"interests":["data","business","analytics"],"branches":["computer science","cse","it","commerce","mathematics"],"description":"Turns data into useful reports and insights.","roadmap":["Learn spreadsheets","Learn SQL","Practice data cleaning","Build dashboards","Create an analysis portfolio"]},
    "Cybersecurity Analyst": {"skills":["networking","linux","security","problem solving"],"interests":["security","investigation","technology"],"branches":["computer science","cse","it","electronics"],"description":"Helps protect systems, networks and information.","roadmap":["Learn computer networks","Practice Linux fundamentals","Study security principles","Use safe lab environments","Learn incident response basics"]},
    "Cloud Engineer": {"skills":["linux","networking","python","cloud"],"interests":["cloud","infrastructure","technology"],"branches":["computer science","cse","it","electronics"],"description":"Builds and manages services on cloud platforms.","roadmap":["Learn networking and Linux","Understand virtualization","Study cloud fundamentals","Practice deployment projects","Learn monitoring and security"]},
    "Full Stack Developer": {"skills":["html","css","javascript","python","sql"],"interests":["web development","coding","design"],"branches":["computer science","cse","it"],"description":"Develops both the frontend and backend of web applications.","roadmap":["Learn HTML and CSS","Learn JavaScript","Build a frontend project","Learn backend and databases","Deploy a complete web app"]},
    "IoT Developer": {"skills":["electronics","programming","sensors","networking"],"interests":["iot","hardware","automation"],"branches":["electronics","ece","electrical","computer science","cse"],"description":"Connects devices, sensors and software to build smart systems.","roadmap":["Learn basic electronics","Study microcontrollers","Connect sensors safely","Learn communication protocols","Build a prototype project"]},
    "Mobile App Developer": {"skills":["java","kotlin","flutter","programming"],"interests":["mobile apps","android","coding"],"branches":["computer science","cse","it"],"description":"Creates applications for mobile devices.","roadmap":["Learn programming basics","Study Android or Flutter","Design app screens","Connect storage and APIs","Publish a portfolio app"]},
    "UI/UX Designer": {"skills":["design","figma","wireframing","communication"],"interests":["design","creativity","user experience"],"branches":["any"],"description":"Designs clear, useful and accessible digital experiences.","roadmap":["Learn design principles","Study user research","Practice wireframing","Create prototypes","Build a design portfolio"]},
    "DevOps Engineer": {"skills":["linux","python","networking","automation","cloud"],"interests":["automation","infrastructure","cloud"],"branches":["computer science","cse","it"],"description":"Improves software delivery through automation and reliable infrastructure.","roadmap":["Learn Linux and Git","Understand networking","Study CI/CD concepts","Practice containers","Build an automated deployment project"]}
}

def _tokens(value):
    return {x.strip().lower() for x in (value or "").replace(";", ",").split(",") if x.strip()}

def recommend(user):
    skills = _tokens(user["skills"])
    interests = _tokens(user["interests"])
    branch = (user["branch"] or "").lower().strip()
    results = []
    for name, data in CAREERS.items():
        skill_hits = len(skills.intersection(data["skills"]))
        interest_hits = len(interests.intersection(data["interests"]))
        skill_score = min(100, round(skill_hits / max(1, min(4, len(data["skills"]))) * 100))
        interest_score = min(100, round(interest_hits / max(1, min(3, len(data["interests"]))) * 100))
        education_score = 100 if any(b in branch for b in data["branches"]) or "any" in data["branches"] else 35
        goal_score = 100 if (user["goal"] or "").lower() in name.lower() or name.lower() in (user["goal"] or "").lower() else 0
        score = round(skill_score*.4 + interest_score*.3 + education_score*.2 + goal_score*.1)
        results.append({"name":name, "score":score, "description":data["description"],
                        "matched_skills":sorted(skills.intersection(data["skills"]))})
    return sorted(results, key=lambda x:x["score"], reverse=True)

def career_details(name, user):
    data = CAREERS.get(name)
    if not data: return None
    skills = _tokens(user["skills"])
    missing = [s for s in data["skills"] if s not in skills]
    return {"name":name, "description":data["description"], "required":data["skills"],
            "missing":missing, "roadmap":data["roadmap"]}

def compare_careers(names):
    return [{"name":n, "description":CAREERS[n]["description"], "skills":CAREERS[n]["skills"],
             "roadmap":CAREERS[n]["roadmap"]} for n in names if n in CAREERS]
