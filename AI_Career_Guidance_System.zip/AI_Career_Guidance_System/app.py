import os
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from database import init_db, query_db, execute_db
from recommendation_engine import recommend, career_details, compare_careers
from chatbot import chatbot_reply

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-development-key")
init_db()

@app.context_processor
def inject_user():
    if session.get("user_id"):
        user = query_db("SELECT id, name, email, education, branch, interests, skills, goal FROM users WHERE id=?",
                        (session["user_id"],), one=True)
        return {"current_user": user}
    return {"current_user": None}

@app.route("/")
def index():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 8:
            flash("Enter your name and email, and use a password with at least 8 characters.", "error")
            return render_template("auth.html", mode="register")
        if query_db("SELECT id FROM users WHERE email=?", (email,), one=True):
            flash("An account with this email already exists.", "error")
            return render_template("auth.html", mode="register")
        execute_db("INSERT INTO users (name,email,password_hash) VALUES (?,?,?)",
                   (name, email, generate_password_hash(password)))
        user = query_db("SELECT id FROM users WHERE email=?", (email,), one=True)
        session["user_id"] = user["id"]
        flash("Account created. Complete your profile to get career recommendations.", "success")
        return redirect(url_for("profile"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = query_db("SELECT * FROM users WHERE email=?", (email,), one=True)
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            return redirect(url_for("dashboard"))
        flash("Incorrect email or password.", "error")
    return render_template("auth.html", mode="login")

def login_required():
    if not session.get("user_id"):
        flash("Please log in first.", "error")
        return False
    return True

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
def dashboard():
    if not login_required(): return redirect(url_for("login"))
    user = query_db("SELECT * FROM users WHERE id=?", (session["user_id"],), one=True)
    results = recommend(user)
    return render_template("dashboard.html", user=user, results=results, details=None, comparison=None, active="dashboard")

@app.route("/profile", methods=["GET", "POST"])
def profile():
    if not login_required(): return redirect(url_for("login"))
    user = query_db("SELECT * FROM users WHERE id=?", (session["user_id"],), one=True)
    if request.method == "POST":
        values = [request.form.get(k, "").strip() for k in ("education","branch","interests","skills","goal")]
        execute_db("UPDATE users SET education=?, branch=?, interests=?, skills=?, goal=? WHERE id=?",
                   (*values, session["user_id"]))
        flash("Profile saved successfully.", "success")
        return redirect(url_for("dashboard"))
    return render_template("dashboard.html", user=user, results=recommend(user), details=None, comparison=None, active="profile")

@app.route("/career/<career_name>")
def career(career_name):
    if not login_required(): return redirect(url_for("login"))
    user = query_db("SELECT * FROM users WHERE id=?", (session["user_id"],), one=True)
    details = career_details(career_name, user)
    if not details:
        flash("Career not found.", "error")
        return redirect(url_for("dashboard"))
    return render_template("dashboard.html", user=user, results=recommend(user), details=details, comparison=None, active="dashboard")

@app.route("/compare", methods=["POST"])
def compare():
    if not login_required(): return redirect(url_for("login"))
    user = query_db("SELECT * FROM users WHERE id=?", (session["user_id"],), one=True)
    names = request.form.getlist("careers")
    comparison = compare_careers(names[:3])
    return render_template("dashboard.html", user=user, results=recommend(user), details=None, comparison=comparison, active="dashboard")

@app.route("/chat", methods=["POST"])
def chat():
    if not login_required(): return redirect(url_for("login"))
    message = request.form.get("message", "").strip()
    reply = chatbot_reply(message)
    execute_db("INSERT INTO chat_history(user_id,message,reply) VALUES (?,?,?)",
               (session["user_id"], message, reply))
    user = query_db("SELECT * FROM users WHERE id=?", (session["user_id"],), one=True)
    return render_template("dashboard.html", user=user, results=recommend(user), details=None,
                           comparison=None, active="chat", chat_message=message, chat_reply=reply)

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
