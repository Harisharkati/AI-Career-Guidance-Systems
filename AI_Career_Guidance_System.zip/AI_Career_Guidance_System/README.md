# AI Career Guidance System

A Flask + SQLite college mini-project. It includes student registration/login, profile management, a rule-based career recommendation engine, skill-gap suggestions, learning roadmaps, career comparison and a rule-based chatbot. It does not require a paid AI API.

## Run on Windows

1. Install Python 3.10 or newer.
2. Extract this ZIP file.
3. Open the extracted `AI_Career_Guidance_System` folder in VS Code.
4. Open **Terminal → New Terminal**.
5. Run:

```powershell
python -m venv venv
venv\Scripts\python.exe -m pip install -r requirements.txt
venv\Scripts\python.exe app.py
```

6. Open **http://127.0.0.1:5000** in your browser.
7. Register with your own email and password, then choose **My Profile** and enter your interests and skills.

Keep the terminal open while using the site. To stop the server, press `Ctrl+C` in the terminal.

## Troubleshooting

- If `python` is not recognised, install Python and select **Add Python to PATH**, then reopen VS Code.
- If the page says refused to connect, check that the terminal still shows `Running on http://127.0.0.1:5000`.
- If port 5000 is busy, change `port=5000` to `port=5001` at the bottom of `app.py`, restart, and open `http://127.0.0.1:5001`.
- The SQLite database is created automatically in the `database` folder on first run.

## Project structure

- `app.py` — Flask routes and authentication
- `database.py` — SQLite setup and database helpers
- `recommendation_engine.py` — weighted career matching, skill gaps and roadmaps
- `chatbot.py` — rule-based chatbot responses
- `templates/` — HTML pages
- `static/` — CSS and JavaScript
- `database/` — SQLite database created automatically
