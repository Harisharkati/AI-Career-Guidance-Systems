document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll('input[type="checkbox"][name="careers"]').forEach(box => {
    box.addEventListener("change", () => {
      const selected = document.querySelectorAll('input[type="checkbox"][name="careers"]:checked');
      if (selected.length > 3) {
        box.checked = false;
        alert("Please select no more than three careers.");
      }
    });
  });
});