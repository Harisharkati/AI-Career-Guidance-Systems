def chatbot_reply(message):
    text = (message or "").lower()
    if not text:
        return "Type a question about careers, skills, learning paths or projects."
    if any(word in text for word in ["hello", "hi", "hey"]):
        return "Hello! I can help you explore careers, required skills and learning roadmaps. What would you like to know?"
    if "resume" in text or "cv" in text:
        return "Create a one-page student resume with your education, technical skills, projects, certifications and contact details. Describe project outcomes clearly."
    if "interview" in text:
        return "Prepare by revising fundamentals, explaining two or three projects, practising problem-solving and preparing examples of teamwork and learning."
    if "roadmap" in text or "start" in text:
        return "Choose one target role, learn its core skills in sequence, practise regularly, build two practical projects and document them in a portfolio."
    if "skill" in text:
        return "Compare your current skills with the skills listed for a career. Start with one foundation skill, practise it in a small project, then move to the next."
    if "ai" in text or "machine learning" in text:
        return "For AI or machine learning, begin with Python, basic statistics and data handling. Then learn core ML concepts and build small, well-explained projects."
    if "web" in text or "developer" in text:
        return "For web development, learn HTML, CSS and JavaScript, then a backend language, databases, Git and deployment. Build a complete project."
    return "I can help with career choices, skill gaps, learning roadmaps, resumes and interview preparation. Try asking: 'What skills do I need for Data Analyst?'"
